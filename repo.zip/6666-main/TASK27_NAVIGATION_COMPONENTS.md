# 📋 المهمة 27: إنشاء مكونات التنقل

## 🎯 الهدف
إنشاء مكونات تنقل متقدمة (Navbar, Sidebar, Breadcrumb, Tabs).

## 📁 الفرع
```
feature/task27-navigation-components
```

## ⏱️ الوقت المتوقع
3-4 ساعات

---

## 📂 الملفات المطلوب إنشاؤها

```
client/src/components/navigation/
├── types.ts              # أنواع TypeScript
├── Navbar.tsx            # شريط التنقل العلوي
├── Sidebar.tsx           # شريط جانبي
├── SidebarItem.tsx       # عنصر الشريط الجانبي
├── Breadcrumb.tsx        # مسار التنقل
├── Tabs.tsx              # علامات تبويب
├── TabPanel.tsx          # لوحة علامة تبويب
├── Pagination.tsx        # تصفح الصفحات
├── Steps.tsx             # خطوات
└── index.ts              # ملف التصدير
```

## 🚫 الملفات الممنوع تعديلها
- `server/**/*`
- `client/src/components/shared/**/*`
- `client/src/pages/**/*`

---

## 📝 ملخص المكونات

| المكون | الوصف |
|:---|:---|
| Navbar | شريط التنقل العلوي |
| Sidebar | شريط جانبي قابل للطي |
| SidebarItem | عنصر مع أيقونة ورابط |
| Breadcrumb | مسار التنقل |
| Tabs | علامات تبويب |
| TabPanel | محتوى علامة التبويب |
| Pagination | تصفح الصفحات |
| Steps | خطوات متتابعة |

---

## ✅ قائمة التحقق النهائية

- [ ] إنشاء مجلد `client/src/components/navigation/`
- [ ] إنشاء جميع المكونات (9 ملفات)
- [ ] إنشاء ملف `index.ts`
- [ ] التأكد من عدم وجود أخطاء TypeScript
- [ ] رفع التغييرات إلى الفرع
