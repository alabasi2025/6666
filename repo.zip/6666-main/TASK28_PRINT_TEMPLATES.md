# 📋 المهمة 28: إنشاء قوالب الطباعة

## 🎯 الهدف
إنشاء قوالب طباعة للسندات والتقارير والفواتير.

## 📁 الفرع
```
feature/task28-print-templates
```

## ⏱️ الوقت المتوقع
3-4 ساعات

---

## 📂 الملفات المطلوب إنشاؤها

```
client/src/components/print/
├── types.ts              # أنواع TypeScript
├── PrintLayout.tsx       # تخطيط الطباعة
├── PrintHeader.tsx       # رأس الطباعة
├── PrintFooter.tsx       # تذييل الطباعة
├── VoucherPrint.tsx      # طباعة السند
├── ReportPrint.tsx       # طباعة التقرير
├── InvoicePrint.tsx      # طباعة الفاتورة
├── ReceiptPrint.tsx      # طباعة الإيصال
├── usePrint.ts           # Hook للطباعة
└── index.ts              # ملف التصدير
```

## 🚫 الملفات الممنوع تعديلها
- `server/**/*`
- `client/src/components/shared/**/*`
- `client/src/pages/**/*`

---

## 📝 ملخص المكونات

| المكون | الوصف |
|:---|:---|
| PrintLayout | تخطيط عام للطباعة |
| PrintHeader | رأس مع شعار ومعلومات الشركة |
| PrintFooter | تذييل مع رقم الصفحة |
| VoucherPrint | قالب طباعة السند |
| ReportPrint | قالب طباعة التقرير |
| InvoicePrint | قالب طباعة الفاتورة |
| ReceiptPrint | قالب طباعة الإيصال |
| usePrint | Hook لتشغيل الطباعة |

---

## ✅ قائمة التحقق النهائية

- [ ] إنشاء مجلد `client/src/components/print/`
- [ ] إنشاء جميع المكونات (9 ملفات)
- [ ] إنشاء ملف `index.ts`
- [ ] التأكد من عدم وجود أخطاء TypeScript
- [ ] رفع التغييرات إلى الفرع
