# 📋 المهمة 23: إنشاء مكونات الرسوم البيانية

## 🎯 الهدف
إنشاء مكونات رسوم بيانية قابلة لإعادة الاستخدام باستخدام Chart.js.

## 📁 الفرع
```
feature/task23-chart-components
```

## ⏱️ الوقت المتوقع
3-4 ساعات

---

## 📂 الملفات المطلوب إنشاؤها

```
client/src/components/charts/
├── types.ts              # أنواع TypeScript
├── ChartContainer.tsx    # حاوية الرسم البياني
├── LineChart.tsx         # رسم بياني خطي
├── BarChart.tsx          # رسم بياني شريطي
├── PieChart.tsx          # رسم بياني دائري
├── DoughnutChart.tsx     # رسم بياني حلقي
├── AreaChart.tsx         # رسم بياني مساحي
├── StatCard.tsx          # بطاقة إحصائية
└── index.ts              # ملف التصدير
```

## 🚫 الملفات الممنوع تعديلها
- `server/**/*`
- `client/src/components/shared/**/*`
- `client/src/pages/**/*`

---

## 📝 ملخص المكونات

| المكون | الوصف |
|:---|:---|
| ChartContainer | حاوية عامة للرسوم البيانية |
| LineChart | رسم بياني خطي للاتجاهات |
| BarChart | رسم بياني شريطي للمقارنات |
| PieChart | رسم بياني دائري للنسب |
| DoughnutChart | رسم بياني حلقي |
| AreaChart | رسم بياني مساحي |
| StatCard | بطاقة إحصائية مع أيقونة |

---

## ✅ قائمة التحقق النهائية

- [ ] إنشاء مجلد `client/src/components/charts/`
- [ ] إنشاء جميع المكونات (8 ملفات)
- [ ] إنشاء ملف `index.ts`
- [ ] التأكد من عدم وجود أخطاء TypeScript
- [ ] رفع التغييرات إلى الفرع
