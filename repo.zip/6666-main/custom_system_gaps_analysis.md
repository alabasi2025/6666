# 🔍 تحليل الفجوات والنواقص في النظام المخصص

> **تاريخ التحليل:** 24 ديسمبر 2025  
> **الغرض:** تحديد الأجزاء الناقصة أو غير المكتملة في فكرة النظام المخصص

---

## 📋 ملخص تنفيذي

بعد الفحص العميق للنظام المخصص، تم تحديد **فجوات جوهرية** في الفكرة الأساسية تحتاج إلى معالجة قبل أن يصبح النظام جاهزاً للاستخدام الفعلي.

### الحالة الحالية

| المكون | الموجود | الناقص | نسبة الاكتمال |
|:---|:---:|:---:|:---:|
| قاعدة البيانات | 12 جدول | 5 جداول | 70% |
| Backend API | 66 وظيفة | 25 وظيفة | 72% |
| Frontend UI | 9 شاشات | 4 شاشات | 69% |
| منطق الأعمال | جزئي | كبير | 50% |

---

## 🚨 الفجوات الجوهرية (Critical Gaps)

### 1. ❌ غياب جدول التحويلات بين الخزائن (Treasury Transfers)

**المشكلة:**
- جدول `customTreasuryTransfers` موجود في Schema لكن **غير مستخدم** في الـ API
- الـ Router الحالي (`customTransfersRouter`) يتعامل مع التحويلات بين **الأنظمة الفرعية** فقط
- لا يوجد دعم للتحويلات بين الخزائن **داخل نفس النظام الفرعي**

**التأثير:**
- لا يمكن تحويل أموال من صندوق إلى بنك داخل نفس النظام
- لا يمكن تتبع التحويلات الداخلية

**الحل المطلوب:**
```
- إنشاء customTreasuryTransfersRouter منفصل
- دعم التحويلات داخل نفس النظام الفرعي
- دعم التحويلات بين أنظمة فرعية مختلفة
```

---

### 2. ❌ عدم ربط الخزائن بالنظام الفرعي بشكل صحيح

**المشكلة:**
- في `customTreasuriesRouter.create`، الحقل `subSystemId` معرّف كـ `optional`
- هذا يعني يمكن إنشاء خزينة **بدون ربطها بنظام فرعي**
- يتعارض مع فكرة أن كل خزينة تنتمي لنظام فرعي

**الكود الحالي:**
```typescript
subSystemId: z.number().optional(), // ❌ يجب أن يكون required
```

**الحل المطلوب:**
```typescript
subSystemId: z.number(), // ✅ مطلوب
```

---

### 3. ❌ غياب سجل حركات الخزينة (Treasury Movements Log)

**المشكلة:**
- لا يوجد جدول لتسجيل **كل حركة** على الخزينة
- الأرصدة تُحدّث مباشرة بدون تاريخ للحركات
- لا يمكن معرفة **من أين جاء المبلغ** أو **إلى أين ذهب**

**التأثير:**
- لا يمكن إنشاء كشف حساب للخزينة
- لا يمكن تتبع الحركات
- لا يمكن التدقيق

**الحل المطلوب:**
```sql
CREATE TABLE custom_treasury_movements (
  id INT PRIMARY KEY AUTO_INCREMENT,
  treasury_id INT NOT NULL,
  movement_type ENUM('receipt', 'payment', 'transfer_in', 'transfer_out', 'adjustment'),
  amount DECIMAL(18,2) NOT NULL,
  balance_before DECIMAL(18,2),
  balance_after DECIMAL(18,2),
  reference_type VARCHAR(50), -- 'receipt_voucher', 'payment_voucher', 'transfer'
  reference_id INT,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

### 4. ❌ غياب نظام الأطراف (Parties/Contacts)

**المشكلة:**
- السندات تستخدم `sourceName` و `destinationName` كنص حر
- لا يوجد جدول للأطراف (عملاء، موردين، موظفين، جهات)
- لا يمكن تتبع المعاملات مع طرف معين

**التأثير:**
- لا يمكن معرفة إجمالي المبالغ المستلمة من شخص معين
- لا يمكن إنشاء كشف حساب لطرف
- تكرار البيانات وأخطاء الكتابة

**الحل المطلوب:**
```sql
CREATE TABLE custom_parties (
  id INT PRIMARY KEY AUTO_INCREMENT,
  business_id INT NOT NULL,
  sub_system_id INT,
  code VARCHAR(20) NOT NULL,
  name_ar VARCHAR(255) NOT NULL,
  name_en VARCHAR(255),
  party_type ENUM('customer', 'supplier', 'employee', 'partner', 'other'),
  phone VARCHAR(50),
  email VARCHAR(255),
  address TEXT,
  tax_number VARCHAR(50),
  credit_limit DECIMAL(18,2) DEFAULT 0,
  current_balance DECIMAL(18,2) DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

### 5. ❌ غياب نظام البنود/التصنيفات (Categories)

**المشكلة:**
- السندات لا تحتوي على **تصنيف** أو **بند**
- لا يمكن معرفة سبب القبض أو الصرف
- لا يمكن إنشاء تقارير حسب التصنيف

**مثال:**
- سند قبض 1000 ريال - من أين؟ إيجار؟ مبيعات؟ قرض؟
- سند صرف 500 ريال - لماذا؟ رواتب؟ مشتريات؟ إيجار؟

**الحل المطلوب:**
```sql
CREATE TABLE custom_categories (
  id INT PRIMARY KEY AUTO_INCREMENT,
  business_id INT NOT NULL,
  sub_system_id INT,
  code VARCHAR(20) NOT NULL,
  name_ar VARCHAR(255) NOT NULL,
  name_en VARCHAR(255),
  category_type ENUM('income', 'expense', 'both'),
  parent_id INT,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW()
);

-- إضافة حقل في السندات
ALTER TABLE custom_receipt_vouchers ADD COLUMN category_id INT;
ALTER TABLE custom_payment_vouchers ADD COLUMN category_id INT;
```

---

### 6. ❌ غياب نظام طرق الدفع (Payment Methods)

**المشكلة:**
- السندات لا تحدد **طريقة الدفع**
- لا يمكن التمييز بين نقدي، شيك، تحويل، شبكة

**الحل المطلوب:**
```sql
-- إضافة حقل في السندات
ALTER TABLE custom_receipt_vouchers ADD COLUMN payment_method ENUM('cash', 'check', 'transfer', 'card', 'wallet');
ALTER TABLE custom_receipt_vouchers ADD COLUMN check_number VARCHAR(50);
ALTER TABLE custom_receipt_vouchers ADD COLUMN check_date DATE;
ALTER TABLE custom_receipt_vouchers ADD COLUMN bank_reference VARCHAR(100);

ALTER TABLE custom_payment_vouchers ADD COLUMN payment_method ENUM('cash', 'check', 'transfer', 'card', 'wallet');
ALTER TABLE custom_payment_vouchers ADD COLUMN check_number VARCHAR(50);
ALTER TABLE custom_payment_vouchers ADD COLUMN check_date DATE;
ALTER TABLE custom_payment_vouchers ADD COLUMN bank_reference VARCHAR(100);
```

---

## 🟡 الفجوات المتوسطة (Medium Gaps)

### 7. ⚠️ غياب التقارير

**الناقص:**
- كشف حساب الخزينة
- كشف حساب الطرف
- تقرير السندات اليومي
- تقرير السندات حسب التصنيف
- تقرير المقارنة بين الفترات
- تقرير الأرصدة

---

### 8. ⚠️ غياب الإحصائيات في الـ API

**الناقص:**
- `getStats` للنظام الفرعي
- `getStats` للخزينة
- `getDailyTotals` للسندات
- `getMonthlyTotals` للسندات

---

### 9. ⚠️ غياب البحث المتقدم

**الناقص:**
- البحث في السندات بالتاريخ
- البحث في السندات بالمبلغ
- البحث في السندات بالطرف
- البحث الشامل

---

### 10. ⚠️ غياب التصدير

**الناقص:**
- تصدير إلى Excel
- تصدير إلى PDF
- طباعة السندات

---

## 🟢 الفجوات البسيطة (Minor Gaps)

### 11. 💡 تحسينات الواجهة

- إضافة رسوم بيانية في لوحة التحكم
- إضافة تنبيهات للأرصدة المنخفضة
- إضافة وضع داكن/فاتح
- تحسين تجربة الهاتف

### 12. 💡 تحسينات الأداء

- إضافة فهارس على الجداول
- إضافة تخزين مؤقت (Caching)
- تحسين الاستعلامات

---

## 📊 ملخص الفجوات

| الرقم | الفجوة | النوع | الأولوية | الجهد |
|:---:|:---|:---:|:---:|:---:|
| 1 | جدول التحويلات بين الخزائن | جوهري | 🔴 عالية | 3 أيام |
| 2 | ربط الخزائن بالنظام الفرعي | جوهري | 🔴 عالية | 1 ساعة |
| 3 | سجل حركات الخزينة | جوهري | 🔴 عالية | 2 يوم |
| 4 | نظام الأطراف | جوهري | 🔴 عالية | 3 أيام |
| 5 | نظام البنود/التصنيفات | جوهري | 🔴 عالية | 2 يوم |
| 6 | طرق الدفع | جوهري | 🔴 عالية | 1 يوم |
| 7 | التقارير | متوسط | 🟡 متوسطة | 5 أيام |
| 8 | الإحصائيات | متوسط | 🟡 متوسطة | 2 يوم |
| 9 | البحث المتقدم | متوسط | 🟡 متوسطة | 2 يوم |
| 10 | التصدير | متوسط | 🟡 متوسطة | 3 أيام |
| 11 | تحسينات الواجهة | بسيط | 🟢 منخفضة | 3 أيام |
| 12 | تحسينات الأداء | بسيط | 🟢 منخفضة | 2 يوم |

**إجمالي الجهد المقدر:** ~29 يوم عمل

---

## 🎯 خطة العمل المقترحة

### المرحلة 1: إصلاح الفجوات الجوهرية (أسبوعين)

**الأسبوع 1:**
1. إنشاء جدول `custom_parties` (الأطراف)
2. إنشاء جدول `custom_categories` (التصنيفات)
3. إنشاء جدول `custom_treasury_movements` (حركات الخزينة)
4. تعديل جداول السندات لإضافة الحقول الناقصة

**الأسبوع 2:**
5. إنشاء `customPartiesRouter`
6. إنشاء `customCategoriesRouter`
7. إنشاء `customTreasuryMovementsRouter`
8. تعديل `customTreasuryTransfersRouter`
9. تعديل الـ Routers الحالية لدعم الحقول الجديدة

### المرحلة 2: إضافة الميزات المتوسطة (أسبوعين)

**الأسبوع 3:**
1. إنشاء شاشة الأطراف
2. إنشاء شاشة التصنيفات
3. تعديل شاشات السندات لدعم الحقول الجديدة

**الأسبوع 4:**
4. إنشاء التقارير الأساسية
5. إضافة الإحصائيات
6. إضافة البحث المتقدم

### المرحلة 3: التحسينات (أسبوع)

**الأسبوع 5:**
1. إضافة التصدير
2. تحسينات الواجهة
3. تحسينات الأداء
4. الاختبارات

---

## 🔄 التغييرات المطلوبة على Schema

### الجداول الجديدة (5 جداول):

1. **custom_parties** - الأطراف
2. **custom_categories** - التصنيفات
3. **custom_treasury_movements** - حركات الخزينة
4. **custom_party_transactions** - حركات الأطراف
5. **custom_settings** - إعدادات النظام المخصص

### التعديلات على الجداول الحالية:

1. **custom_receipt_vouchers:**
   - إضافة `party_id`
   - إضافة `category_id`
   - إضافة `payment_method`
   - إضافة `check_number`, `check_date`, `bank_reference`

2. **custom_payment_vouchers:**
   - إضافة `party_id`
   - إضافة `category_id`
   - إضافة `payment_method`
   - إضافة `check_number`, `check_date`, `bank_reference`

3. **custom_treasuries:**
   - تغيير `sub_system_id` من optional إلى required

---

## ✅ الخلاصة

النظام المخصص الحالي يحتوي على **بنية أساسية جيدة** لكنه **غير مكتمل** للاستخدام الفعلي.

**الفجوات الرئيسية:**
1. ❌ لا يوجد نظام أطراف (عملاء/موردين)
2. ❌ لا يوجد نظام تصنيفات (بنود)
3. ❌ لا يوجد سجل حركات للخزينة
4. ❌ لا يوجد دعم لطرق الدفع
5. ❌ التحويلات بين الخزائن غير مكتملة

**التوصية:**
يجب إكمال الفجوات الجوهرية (1-6) قبل البدء في إدخال البيانات الفعلية.

---

**آخر تحديث:** 24 ديسمبر 2025
