# 📋 المهمة 30: إنشاء نظام الترجمة (i18n)

## 🎯 الهدف
إنشاء نظام ترجمة متكامل يدعم اللغة العربية والإنجليزية.

## 📁 الفرع
```
feature/task30-i18n-system
```

## ⏱️ الوقت المتوقع
4-5 ساعات

---

## 📂 الملفات المطلوب إنشاؤها

```
client/src/i18n/
├── types.ts              # أنواع TypeScript
├── config.ts             # إعدادات i18n
├── locales/
│   ├── ar/
│   │   ├── common.json   # ترجمات عامة
│   │   ├── auth.json     # ترجمات المصادقة
│   │   ├── voucher.json  # ترجمات السندات
│   │   ├── party.json    # ترجمات الأطراف
│   │   ├── treasury.json # ترجمات الخزائن
│   │   └── errors.json   # ترجمات الأخطاء
│   └── en/
│       ├── common.json
│       ├── auth.json
│       ├── voucher.json
│       ├── party.json
│       ├── treasury.json
│       └── errors.json
├── hooks/
│   ├── useTranslation.ts # Hook للترجمة
│   └── useLocale.ts      # Hook للغة
├── components/
│   ├── LanguageSwitcher.tsx # مبدل اللغة
│   └── TranslatedText.tsx   # نص مترجم
├── utils.ts              # أدوات مساعدة
└── index.ts              # ملف التصدير
```

## 🚫 الملفات الممنوع تعديلها
- `server/**/*`
- `client/src/components/shared/**/*`
- `client/src/pages/**/*`

---

## 📝 ملخص المكونات

| المكون/الملف | الوصف |
|:---|:---|
| config.ts | إعدادات i18n الأساسية |
| locales/ | ملفات الترجمة JSON |
| useTranslation | Hook للوصول للترجمات |
| useLocale | Hook لتغيير اللغة |
| LanguageSwitcher | مكون لتبديل اللغة |
| TranslatedText | مكون لعرض نص مترجم |

---

## 📝 مثال على ملف الترجمة

```json
// locales/ar/common.json
{
  "app": {
    "name": "نظام إدارة الطاقة",
    "welcome": "مرحباً بك"
  },
  "actions": {
    "save": "حفظ",
    "cancel": "إلغاء",
    "delete": "حذف",
    "edit": "تعديل",
    "add": "إضافة",
    "search": "بحث",
    "filter": "تصفية",
    "export": "تصدير",
    "print": "طباعة"
  },
  "messages": {
    "success": "تمت العملية بنجاح",
    "error": "حدث خطأ",
    "confirm": "هل أنت متأكد؟",
    "loading": "جاري التحميل..."
  }
}
```

---

## ✅ قائمة التحقق النهائية

- [ ] إنشاء مجلد `client/src/i18n/`
- [ ] إنشاء ملفات الترجمة (12 ملف JSON)
- [ ] إنشاء Hooks (2 ملفات)
- [ ] إنشاء المكونات (2 ملفات)
- [ ] إنشاء ملفات الإعدادات والأدوات
- [ ] إنشاء ملف `index.ts`
- [ ] التأكد من عدم وجود أخطاء TypeScript
- [ ] رفع التغييرات إلى الفرع
