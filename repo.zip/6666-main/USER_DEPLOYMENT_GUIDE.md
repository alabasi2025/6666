# دليل المستخدم: دمج ونشر النظام المخصص v2.2.0

## مرحباً! 👋

تم رفع جميع التغييرات بنجاح إلى GitHub repository الخاص بك. الآن حان الوقت لدمج هذه التغييرات على جهازك المحلي (Windows) ونشر النظام.

---

## المرحلة 6: الدمج والنشر على جهازك

### الخطوة 1: فتح Terminal على جهازك

افتح **PowerShell** أو **Command Prompt** على جهازك وانتقل إلى مجلد المشروع:

```bash
cd C:\Users\qbas\33333\6666
```

*(تأكد من المسار الصحيح لمجلد المشروع على جهازك)*

---

### الخطوة 2: Pull التغييرات من GitHub

```bash
git pull origin main
```

يجب أن ترى رسالة مثل:

```
Updating d6df427..4ab8a7b
Fast-forward
 DEPLOYMENT_INSTRUCTIONS.md                         | 450 ++++++++++++++++++++
 TESTING_CHECKLIST.md                               | 320 ++++++++++++++
 client/src/pages/CustomSystem/v2/AccountsPage.tsx | 500 +++++++++++++++++++++
 ... (21 files changed, 8836 insertions(+))
```

---

### الخطوة 3: التحقق من الملفات الجديدة

تأكد من وجود الملفات التالية:

**Database:**
- `drizzle/schemas/customSystemV2.ts`
- `drizzle/migrations/0014_custom_system_v2.sql`

**Backend:**
- `server/routes/customSystem/v2/currencies.ts`
- `server/routes/customSystem/v2/exchangeRates.ts`
- `server/routes/customSystem/v2/journalEntries.ts`
- `server/routes/customSystem/v2/operations.ts`
- وملفات أخرى...

**Frontend:**
- `client/src/pages/CustomSystem/v2/CurrenciesPage.tsx`
- `client/src/pages/CustomSystem/v2/OperationsPage.tsx`
- وملفات أخرى...

---

### الخطوة 4: عمل Backup لقاعدة البيانات ⚠️

**مهم جداً:** قبل تشغيل Migration، يجب عمل Backup لقاعدة البيانات!

إذا كنت تستخدم PostgreSQL:

```bash
pg_dump -U postgres -d your_database_name > backup_before_v2.2.0.sql
```

أو استخدم أداة Backup الخاصة بقاعدة البيانات التي تستخدمها.

---

### الخطوة 5: تشغيل Database Migration

```bash
pnpm drizzle-kit push
```

أو:

```bash
pnpm drizzle-kit migrate
```

**ماذا سيحدث:**
- إنشاء 7 جداول جديدة
- تعديل 3 جداول موجودة
- حذف 3 جداول قديمة (إذا كانت فارغة)
- إضافة بيانات أولية (العملات الأساسية)

**إذا ظهرت أخطاء:**
- تحقق من اتصال قاعدة البيانات
- تحقق من صلاحيات المستخدم
- راجع ملف `DEPLOYMENT_INSTRUCTIONS.md` لحلول الأخطاء

---

### الخطوة 6: تحديث Backend Routes

افتح ملف `server/index.ts` أو `server/app.ts` وأضف:

```typescript
import customSystemV2Router from "./routes/customSystem/v2";

// في قسم الـ routes
app.use("/api/custom-system/v2", customSystemV2Router);
```

---

### الخطوة 7: تحديث Frontend Routes

افتح ملف `client/src/App.tsx` أو `client/src/routes/index.tsx` وأضف:

```typescript
import {
  CurrenciesPage,
  ExchangeRatesPage,
  AccountsPage,
  JournalEntriesPage,
  OperationsPage,
} from "./pages/CustomSystem/v2";

// في قسم الـ routes
<Route path="/custom-system/v2/currencies" element={<CurrenciesPage />} />
<Route path="/custom-system/v2/exchange-rates" element={<ExchangeRatesPage />} />
<Route path="/custom-system/v2/accounts" element={<AccountsPage />} />
<Route path="/custom-system/v2/journal-entries" element={<JournalEntriesPage />} />
<Route path="/custom-system/v2/operations" element={<OperationsPage />} />
```

---

### الخطوة 8: تحديث Navigation Menu

افتح ملف القائمة الجانبية وأضف:

```typescript
{
  title: "النظام المخصص v2",
  items: [
    {
      title: "شاشة العمليات",
      path: "/custom-system/v2/operations",
    },
    {
      title: "القيود اليومية",
      path: "/custom-system/v2/journal-entries",
    },
    {
      title: "الحسابات",
      path: "/custom-system/v2/accounts",
    },
    {
      title: "العملات",
      path: "/custom-system/v2/currencies",
    },
    {
      title: "أسعار الصرف",
      path: "/custom-system/v2/exchange-rates",
    },
  ],
}
```

---

### الخطوة 9: تثبيت Dependencies (إذا لزم الأمر)

```bash
pnpm install
```

---

### الخطوة 10: Build المشروع

```bash
# Build Backend
pnpm build

# Build Frontend
cd client
pnpm build
cd ..
```

---

### الخطوة 11: إعادة تشغيل الخادم

```bash
# إيقاف الخادم الحالي (Ctrl+C)

# تشغيل الخادم الجديد
pnpm start
```

أو إذا كنت تستخدم PM2:

```bash
pm2 restart all
```

---

## الاختبار

### 1. اختبار Backend API

افتح Postman أو أي أداة API testing واختبر:

```
GET http://localhost:3000/api/custom-system/v2/currencies
```

يجب أن ترى قائمة العملات (على الأقل العملات الأساسية).

### 2. اختبار Frontend UI

افتح المتصفح وانتقل إلى:

```
http://localhost:3000/custom-system/v2/operations
```

يجب أن ترى شاشة العمليات الموحدة مع 3 بطاقات:
- سند قبض
- سند صرف
- تحويل

### 3. اختبار سيناريو كامل

**السيناريو: إنشاء سند قبض**

1. انتقل إلى صفحة الحسابات
2. أنشئ حسابين:
   - حساب الصندوق (نوع: أصول)
   - حساب العملاء (نوع: أصول)

3. انتقل إلى صفحة العملات
4. تأكد من وجود عملة واحدة على الأقل (مثل SAR)

5. انتقل إلى شاشة العمليات
6. انقر على "سند قبض"
7. املأ البيانات:
   - من حساب: العملاء
   - إلى حساب: الصندوق
   - المبلغ: 1000
   - العملة: SAR
8. احفظ

9. انتقل إلى صفحة القيود اليومية
10. يجب أن ترى قيد يومي جديد تم إنشاؤه تلقائياً
11. افتح القيد وتحقق من:
    - السطر الأول: الصندوق (مدين: 1000)
    - السطر الثاني: العملاء (دائن: 1000)
    - القيد متوازن ✓
    - الحالة: مرحّل ✓

12. انتقل إلى صفحة الحسابات
13. افتح حساب الصندوق
14. تحقق من الرصيد: +1000 ✓

---

## استكشاف الأخطاء

### مشكلة: Migration فشل

**الخطأ:** `relation "customCurrencies" already exists`

**الحل:**
- الجدول موجود بالفعل
- تخطى هذا الخطأ أو احذف الجدول يدوياً

**الخطأ:** `cannot drop table "customTransactions" because other objects depend on it`

**الحل:**
- توجد بيانات في الجدول
- احذف البيانات أولاً أو عدّل Migration

### مشكلة: API لا يعمل

**الخطأ:** `Cannot GET /api/custom-system/v2/currencies`

**الحل:**
- تأكد من تسجيل الـ router في `server/index.ts`
- تأكد من إعادة تشغيل الخادم
- راجع logs الخادم

### مشكلة: Frontend لا يعرض الصفحات

**الخطأ:** `Page not found`

**الحل:**
- تأكد من إضافة الـ routes في `App.tsx`
- تأكد من build الـ Frontend
- راجع console المتصفح

---

## الدعم

إذا واجهت أي مشاكل:

1. راجع ملف `DEPLOYMENT_INSTRUCTIONS.md` للتفاصيل الكاملة
2. راجع ملف `TESTING_CHECKLIST.md` للتحقق من الخطوات
3. راجع ملف `API_DOCUMENTATION.md` لتفاصيل الـ API
4. راجع ملف `README.md` في مجلد Frontend

---

## ملخص التغييرات

### ما تم إضافته:

**قاعدة البيانات:**
- 7 جداول جديدة للنظام المحاسبي
- دعم متعدد العملات
- نظام القيد المزدوج

**Backend API:**
- 46 endpoint جديد
- 7 routers كاملة
- معالجة تلقائية للقيود اليومية

**Frontend UI:**
- 5 صفحات جديدة
- واجهة مستخدم احترافية
- دعم RTL

**التوثيق:**
- 4 ملفات توثيق شاملة

### ما تم تعديله:

- جدول الحسابات (دعم متعدد العملات)
- جدول الأنظمة الفرعية (حسابات افتراضية)
- جدول السندات (ربط بالقيود اليومية)

### ما تم حذفه:

- جدول المعاملات القديم
- جدول الخزائن القديم
- جدول حركات الخزائن القديم

---

## الإصدار

**Version:** 2.2.0  
**Release Date:** 2025-01-01  
**Status:** Production Ready

---

## تهانينا! 🎉

إذا وصلت إلى هنا ونجحت جميع الخطوات، فقد تم نشر النظام المخصص v2.2.0 بنجاح!

الآن لديك نظام محاسبي كامل بالقيد المزدوج مع دعم متعدد العملات.

**استمتع بالنظام الجديد!** 🚀
