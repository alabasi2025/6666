# 📋 المهمة 26: إنشاء مكونات التخطيط

## 🎯 الهدف
إنشاء مكونات تخطيط قابلة لإعادة الاستخدام (Container, Grid, Flex, Card).

## 📁 الفرع
```
feature/task26-layout-components
```

## ⏱️ الوقت المتوقع
3-4 ساعات

---

## 📂 الملفات المطلوب إنشاؤها

```
client/src/components/layout/
├── types.ts              # أنواع TypeScript
├── Container.tsx         # حاوية مركزية
├── Grid.tsx              # شبكة
├── Flex.tsx              # تخطيط مرن
├── Card.tsx              # بطاقة
├── Section.tsx           # قسم
├── Divider.tsx           # فاصل
├── Spacer.tsx            # مسافة
├── Stack.tsx             # تكديس عمودي/أفقي
└── index.ts              # ملف التصدير
```

## 🚫 الملفات الممنوع تعديلها
- `server/**/*`
- `client/src/components/shared/**/*`
- `client/src/pages/**/*`

---

## 📝 ملخص المكونات

| المكون | الوصف |
|:---|:---|
| Container | حاوية مركزية مع عرض أقصى |
| Grid | شبكة مع أعمدة متجاوبة |
| Flex | تخطيط مرن |
| Card | بطاقة مع رأس وجسم وتذييل |
| Section | قسم مع عنوان |
| Divider | فاصل أفقي/عمودي |
| Spacer | مسافة قابلة للتخصيص |
| Stack | تكديس عناصر |

---

## ✅ قائمة التحقق النهائية

- [ ] إنشاء مجلد `client/src/components/layout/`
- [ ] إنشاء جميع المكونات (9 ملفات)
- [ ] إنشاء ملف `index.ts`
- [ ] التأكد من عدم وجود أخطاء TypeScript
- [ ] رفع التغييرات إلى الفرع
