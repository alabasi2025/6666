# 📋 المهمة 22: إنشاء مكونات النماذج

## 🎯 الهدف
إنشاء مكونات نماذج متقدمة قابلة لإعادة الاستخدام.

## 📁 الفرع
```
feature/task22-form-components
```

## ⏱️ الوقت المتوقع
4-5 ساعات

---

## 📂 الملفات المطلوب إنشاؤها

```
client/src/components/forms/
├── FormField.tsx         # حقل نموذج عام
├── FormInput.tsx         # حقل إدخال نص
├── FormSelect.tsx        # قائمة منسدلة
├── FormTextarea.tsx      # منطقة نص
├── FormCheckbox.tsx      # خانة اختيار
├── FormRadio.tsx         # أزرار راديو
├── FormDatePicker.tsx    # منتقي التاريخ
├── FormNumberInput.tsx   # حقل رقمي
├── FormFileUpload.tsx    # رفع الملفات
├── FormSwitch.tsx        # مفتاح تبديل
└── index.ts              # ملف التصدير
```

## 🚫 الملفات الممنوع تعديلها
- `server/**/*`
- `client/src/components/shared/**/*` - لتجنب التعارض مع المهمة 10
- `client/src/pages/**/*`

---

## 📝 ملخص المكونات

| المكون | الوصف |
|:---|:---|
| FormField | غلاف عام للحقول مع Label و Error |
| FormInput | حقل إدخال نص مع دعم RTL |
| FormSelect | قائمة منسدلة مع بحث |
| FormTextarea | منطقة نص متعددة الأسطر |
| FormCheckbox | خانة اختيار مع label |
| FormRadio | مجموعة أزرار راديو |
| FormDatePicker | منتقي تاريخ هجري/ميلادي |
| FormNumberInput | حقل رقمي مع تنسيق |
| FormFileUpload | رفع ملفات مع معاينة |
| FormSwitch | مفتاح تبديل on/off |

---

## 📝 خطوات التنفيذ

### الخطوة 1: استنساخ المستودع والانتقال للفرع
```bash
gh repo clone alabasi2025/6666
cd 6666
git checkout feature/task22-form-components
```

### الخطوة 2: إنشاء المجلد
```bash
mkdir -p client/src/components/forms
```

### الخطوة 3-12: إنشاء المكونات
(راجع الكود التفصيلي في الملف)

### الخطوة 13: رفع التغييرات
```bash
git add client/src/components/forms/
git commit -m "feat(forms): إضافة مكونات النماذج

- FormField: غلاف عام للحقول
- FormInput: حقل إدخال نص
- FormSelect: قائمة منسدلة
- FormTextarea: منطقة نص
- FormCheckbox: خانة اختيار
- FormRadio: أزرار راديو
- FormDatePicker: منتقي التاريخ
- FormNumberInput: حقل رقمي
- FormFileUpload: رفع الملفات
- FormSwitch: مفتاح تبديل"

git push origin feature/task22-form-components
```

---

## ✅ قائمة التحقق النهائية

- [ ] إنشاء مجلد `client/src/components/forms/`
- [ ] إنشاء جميع المكونات (10 ملفات)
- [ ] إنشاء ملف `index.ts`
- [ ] التأكد من عدم وجود أخطاء TypeScript
- [ ] رفع التغييرات إلى الفرع
