# 📋 المهمة 25: إنشاء مكونات النوافذ المنبثقة

## 🎯 الهدف
إنشاء مكونات نوافذ منبثقة متنوعة (Modal, Dialog, Drawer, Popover).

## 📁 الفرع
```
feature/task25-modal-components
```

## ⏱️ الوقت المتوقع
3-4 ساعات

---

## 📂 الملفات المطلوب إنشاؤها

```
client/src/components/modals/
├── types.ts              # أنواع TypeScript
├── Modal.tsx             # نافذة منبثقة أساسية
├── ConfirmDialog.tsx     # حوار تأكيد
├── AlertDialog.tsx       # حوار تنبيه
├── FormModal.tsx         # نافذة نموذج
├── Drawer.tsx            # درج جانبي
├── Popover.tsx           # نافذة منبثقة صغيرة
├── Tooltip.tsx           # تلميح
└── index.ts              # ملف التصدير
```

## 🚫 الملفات الممنوع تعديلها
- `server/**/*`
- `client/src/components/shared/**/*`
- `client/src/pages/**/*`

---

## 📝 ملخص المكونات

| المكون | الوصف |
|:---|:---|
| Modal | نافذة منبثقة أساسية |
| ConfirmDialog | حوار تأكيد مع أزرار |
| AlertDialog | حوار تنبيه (نجاح/خطأ/تحذير) |
| FormModal | نافذة تحتوي نموذج |
| Drawer | درج جانبي (يمين/يسار) |
| Popover | نافذة منبثقة صغيرة |
| Tooltip | تلميح عند التمرير |

---

## ✅ قائمة التحقق النهائية

- [ ] إنشاء مجلد `client/src/components/modals/`
- [ ] إنشاء جميع المكونات (8 ملفات)
- [ ] إنشاء ملف `index.ts`
- [ ] التأكد من عدم وجود أخطاء TypeScript
- [ ] رفع التغييرات إلى الفرع
