# دليل بيئة الإنتاج - Energy Management System

## 📍 المسار
```
D:\6666
```

## ✅ ما تم إنجازه

### 1. نسخ المشروع
- ✅ تم نسخ المشروع من `C:\Users\qbas\33333\6666-new` إلى `D:\6666`
- ✅ تم نسخ جميع الملفات والمجلدات

### 2. تثبيت المتطلبات
- ✅ تم حذف `node_modules` القديم
- ✅ تم تثبيت جميع المتطلبات باستخدام `pnpm install`
- ✅ جميع الحزم مثبتة بنجاح

### 3. بناء المشروع
- ✅ تم بناء المشروع باستخدام `pnpm run build`
- ✅ اكتمل البناء في 20 ثانية
- ✅ تم إنشاء مجلد `dist` بنجاح

### 4. إعداد البيئة
- ✅ تم إنشاء ملف `.env` للإنتاج
- ✅ تم تعيين `NODE_ENV=production`
- ✅ تم تعيين `PORT=3000`

### 5. ملفات التشغيل
- ✅ تم إنشاء `start-production.bat`

---

## 🚀 كيفية التشغيل

### الطريقة 1: باستخدام ملف BAT (الأسهل)
```cmd
cd D:\6666
start-production.bat
```

### الطريقة 2: يدوياً
```cmd
cd D:\6666
pnpm run db:push
pnpm run start
```

---

## ⚙️ الإعدادات

### ملف `.env`
```env
DATABASE_URL=mysql://root:@localhost:3306/energy_production
PORT=3000
NODE_ENV=production
DEFAULT_ADMIN_PHONE=0500000000
DEFAULT_ADMIN_PASSWORD=Admin@2025!Secure
```

### قاعدة البيانات
- **الاسم**: `energy_production`
- **المستخدم**: `root`
- **كلمة المرور**: (فارغة)
- **المنفذ**: `3306`

⚠️ **مهم**: تأكد من تشغيل MySQL قبل بدء الخادم!

---

## 🔗 الوصول

بعد التشغيل، يمكن الوصول للتطبيق عبر:

### محلياً
```
http://localhost:3000
```

### عبر النفق (Cloudflare Tunnel)
```
https://energy.alabasi.uk
```

⚠️ **ملاحظة**: تأكد من أن النفق موجه إلى المنفذ 3000

---

## 📊 معلومات النظام

| المعلومة | القيمة |
|----------|--------|
| **نظام التشغيل** | Windows 10 (19045) |
| **المعالج** | 8 أنوية |
| **الذاكرة** | 32 GB |
| **القرص D** | 130 GB متاح |

---

## 🛠️ الأوامر المفيدة

### إيقاف الخادم
```
Ctrl + C
```

### إعادة البناء
```cmd
cd D:\6666
pnpm run build
```

### تحديث قاعدة البيانات
```cmd
cd D:\6666
pnpm run db:push
```

### عرض السجلات
```cmd
cd D:\6666
type logs\production.log
```

---

## 🔐 الأمان

### تغيير كلمة مرور المدير
عدّل في ملف `.env`:
```env
DEFAULT_ADMIN_PASSWORD=كلمة_مرور_قوية_جداً
```

### تأمين قاعدة البيانات
```sql
CREATE USER 'energy_user'@'localhost' IDENTIFIED BY 'password_here';
GRANT ALL PRIVILEGES ON energy_production.* TO 'energy_user'@'localhost';
FLUSH PRIVILEGES;
```

ثم عدّل `DATABASE_URL` في `.env`:
```env
DATABASE_URL=mysql://energy_user:password_here@localhost:3306/energy_production
```

---

## 📝 ملاحظات

1. **بيئة الإنتاج فقط**: هذا المشروع في `D:\6666` مخصص للإنتاج
2. **بيئة التطوير**: المشروع في `C:\Users\qbas\33333\6666` للتطوير
3. **النسخ الاحتياطي**: يُنصح بعمل نسخة احتياطية من قاعدة البيانات بانتظام
4. **التحديثات**: لتحديث المشروع، استخدم `git pull` في بيئة التطوير ثم انسخ إلى الإنتاج

---

## 🆘 المساعدة

### الخادم لا يعمل؟
1. تحقق من تشغيل MySQL
2. تحقق من ملف `.env`
3. تحقق من السجلات

### خطأ في قاعدة البيانات؟
```cmd
pnpm run db:push
```

### خطأ في البناء؟
```cmd
rmdir /s /q dist
pnpm run build
```

---

## ✅ الخطوات التالية

1. ✅ تشغيل الخادم باستخدام `start-production.bat`
2. ⏳ اختبار الوصول عبر `http://localhost:3000`
3. ⏳ اختبار الوصول عبر النفق `https://energy.alabasi.uk`
4. ⏳ تسجيل الدخول بحساب المدير
5. ⏳ إعداد النسخ الاحتياطي التلقائي

---

**تم الإعداد بنجاح! 🎉**
