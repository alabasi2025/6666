# 📋 المهمة 5: توثيق API للنظام المخصص

## 🎯 الهدف
إنشاء توثيق شامل لجميع نقاط API في النظام المخصص (Custom System).

---

## 📁 الملفات المسموح إنشاؤها/تعديلها

| الملف | نوع التعديل |
|:---|:---|
| `docs/api/custom-system.md` | إنشاء جديد |
| `docs/api/custom-parties.md` | إنشاء جديد |
| `docs/api/custom-categories.md` | إنشاء جديد |
| `docs/api/custom-treasuries.md` | إنشاء جديد |
| `docs/api/custom-vouchers.md` | إنشاء جديد |

---

## 🚫 الملفات الممنوع تعديلها (لتجنب التعارض)

| الملف | السبب |
|:---|:---|
| `server/*.ts` | المهمة 3 تعمل عليها |
| `client/src/**/*.tsx` | المهمة 2 تعمل عليها |
| `drizzle/schema.ts` | المهمة 4 تعمل عليها |

---

## 📋 الخطوات التفصيلية

### الخطوة 1: استنساخ المستودع والتبديل للفرع

```bash
# استنساخ المستودع
gh repo clone alabasi2025/6666
cd 6666

# التبديل للفرع المخصص
git checkout feature/task5-api-documentation
git pull origin feature/task5-api-documentation

# إنشاء مجلد التوثيق
mkdir -p docs/api
```

---

### الخطوة 2: قراءة ملف customSystemRouter.ts

اقرأ الملف `server/customSystemRouter.ts` لفهم جميع الـ Routers والوظائف المتاحة.

---

### الخطوة 3: إنشاء ملف التوثيق الرئيسي

أنشئ ملف `docs/api/custom-system.md`:

```markdown
# 📚 توثيق API - النظام المخصص (Custom System)

## نظرة عامة

النظام المخصص يوفر مجموعة من APIs لإدارة:
- الأنظمة الفرعية (Sub Systems)
- الخزائن (Treasuries)
- الأطراف (Parties)
- التصنيفات (Categories)
- سندات القبض والصرف (Vouchers)
- التحويلات والتسويات

## Base URL

```
/api/trpc/customSystem
```

## الـ Routers المتاحة

| Router | الوصف | الرابط |
|:---|:---|:---|
| subSystems | إدارة الأنظمة الفرعية | [التفاصيل](./custom-subsystems.md) |
| treasuries | إدارة الخزائن | [التفاصيل](./custom-treasuries.md) |
| parties | إدارة الأطراف | [التفاصيل](./custom-parties.md) |
| categories | إدارة التصنيفات | [التفاصيل](./custom-categories.md) |
| vouchers | سندات القبض والصرف | [التفاصيل](./custom-vouchers.md) |

## المصادقة

جميع الـ APIs تتطلب مصادقة عبر الجلسة (Session-based authentication).

## صيغة الاستجابة

جميع الاستجابات بصيغة JSON.
```

---

### الخطوة 4: توثيق API الأطراف

أنشئ ملف `docs/api/custom-parties.md`:

```markdown
# 📚 API الأطراف (Custom Parties)

## نظرة عامة

إدارة الأطراف (العملاء، الموردين، الموظفين، الشركاء، الجهات الحكومية).

## Endpoints

### 1. قائمة الأطراف

```
GET /api/trpc/customSystem.parties.list
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| businessId | number | ✅ | معرف الشركة |
| subSystemId | number | ❌ | معرف النظام الفرعي |
| partyType | string | ❌ | نوع الطرف (customer, supplier, employee, partner, government) |
| search | string | ❌ | نص البحث |
| isActive | boolean | ❌ | حالة النشاط |

**مثال الاستجابة:**
```json
{
  "result": {
    "data": [
      {
        "id": 1,
        "code": "C001",
        "nameAr": "شركة الأمل",
        "nameEn": "Al-Amal Company",
        "partyType": "customer",
        "phone": "0501234567",
        "currentBalance": "5000.00",
        "isActive": true
      }
    ]
  }
}
```

---

### 2. إنشاء طرف جديد

```
POST /api/trpc/customSystem.parties.create
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| businessId | number | ✅ | معرف الشركة |
| code | string | ✅ | كود الطرف |
| nameAr | string | ✅ | الاسم بالعربية |
| nameEn | string | ❌ | الاسم بالإنجليزية |
| partyType | string | ✅ | نوع الطرف |
| phone | string | ❌ | رقم الهاتف |
| mobile | string | ❌ | رقم الجوال |
| email | string | ❌ | البريد الإلكتروني |
| city | string | ❌ | المدينة |
| country | string | ❌ | الدولة |
| address | string | ❌ | العنوان |
| taxNumber | string | ❌ | الرقم الضريبي |
| commercialRegister | string | ❌ | السجل التجاري |
| creditLimit | number | ❌ | حد الائتمان |
| currency | string | ❌ | العملة |
| notes | string | ❌ | ملاحظات |

**مثال الطلب:**
```json
{
  "businessId": 1,
  "code": "C002",
  "nameAr": "مؤسسة النور",
  "partyType": "customer",
  "phone": "0509876543"
}
```

---

### 3. تحديث طرف

```
POST /api/trpc/customSystem.parties.update
```

**المعاملات:**
نفس معاملات الإنشاء + `id` (معرف الطرف)

---

### 4. حذف طرف

```
POST /api/trpc/customSystem.parties.delete
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| id | number | ✅ | معرف الطرف |

---

### 5. الحصول على رصيد طرف

```
GET /api/trpc/customSystem.parties.getBalance
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| partyId | number | ✅ | معرف الطرف |

**مثال الاستجابة:**
```json
{
  "result": {
    "data": {
      "currentBalance": "5000.00",
      "totalDebit": "10000.00",
      "totalCredit": "5000.00"
    }
  }
}
```

---

### 6. كشف حساب طرف

```
GET /api/trpc/customSystem.parties.getStatement
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| partyId | number | ✅ | معرف الطرف |
| fromDate | string | ❌ | من تاريخ |
| toDate | string | ❌ | إلى تاريخ |

**مثال الاستجابة:**
```json
{
  "result": {
    "data": {
      "party": { "id": 1, "nameAr": "شركة الأمل" },
      "openingBalance": "0.00",
      "transactions": [
        {
          "id": 1,
          "date": "2024-01-15",
          "type": "receipt",
          "reference": "RV-001",
          "debit": "5000.00",
          "credit": "0.00",
          "balance": "5000.00"
        }
      ],
      "closingBalance": "5000.00"
    }
  }
}
```
```

---

### الخطوة 5: توثيق API التصنيفات

أنشئ ملف `docs/api/custom-categories.md` بنفس النمط.

---

### الخطوة 6: توثيق API الخزائن

أنشئ ملف `docs/api/custom-treasuries.md` بنفس النمط.

---

### الخطوة 7: توثيق API السندات

أنشئ ملف `docs/api/custom-vouchers.md` بنفس النمط.

---

### الخطوة 8: رفع التغييرات

```bash
# إضافة الملفات
git add docs/

# إنشاء commit
git commit -m "docs(api): إضافة توثيق شامل لـ API النظام المخصص

✅ توثيق API الأطراف (parties)
✅ توثيق API التصنيفات (categories)
✅ توثيق API الخزائن (treasuries)
✅ توثيق API السندات (vouchers)
✅ توثيق API الأنظمة الفرعية (subSystems)"

# رفع التغييرات
git push origin feature/task5-api-documentation
```

---

## ✅ قائمة التحقق النهائية

| # | المهمة | الحالة |
|:---:|:---|:---:|
| 1 | استنساخ المستودع | ⬜ |
| 2 | التبديل للفرع الصحيح | ⬜ |
| 3 | إنشاء مجلد docs/api | ⬜ |
| 4 | إنشاء custom-system.md | ⬜ |
| 5 | إنشاء custom-parties.md | ⬜ |
| 6 | إنشاء custom-categories.md | ⬜ |
| 7 | إنشاء custom-treasuries.md | ⬜ |
| 8 | إنشاء custom-vouchers.md | ⬜ |
| 9 | إنشاء custom-subsystems.md | ⬜ |
| 10 | رفع التغييرات | ⬜ |

---

## 📊 الملفات المطلوبة

| الملف | المحتوى |
|:---|:---|
| `docs/api/custom-system.md` | نظرة عامة وفهرس |
| `docs/api/custom-parties.md` | توثيق API الأطراف |
| `docs/api/custom-categories.md` | توثيق API التصنيفات |
| `docs/api/custom-treasuries.md` | توثيق API الخزائن |
| `docs/api/custom-vouchers.md` | توثيق API السندات |
| `docs/api/custom-subsystems.md` | توثيق API الأنظمة الفرعية |

---

## 🎯 الوقت المتوقع

**3-4 ساعات**
