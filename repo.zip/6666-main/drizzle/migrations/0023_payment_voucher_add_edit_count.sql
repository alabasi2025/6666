ALTER TABLE `custom_payment_vouchers` ADD `edit_count` int DEFAULT 0 NOT NULL;

