# 📚 API الأنظمة الفرعية (Custom Sub-Systems)

## نظرة عامة

إدارة الأنظمة الفرعية داخل الشركة.

## Endpoints

### 1. قائمة الأنظمة الفرعية

```
GET /api/trpc/customSystem.subSystems.list
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| businessId | number | ✅ | معرف الشركة |

### 2. إنشاء نظام فرعي جديد

```
POST /api/trpc/customSystem.subSystems.create
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| businessId | number | ✅ | معرف الشركة |
| code | string | ✅ | كود النظام |
| nameAr | string | ✅ | الاسم بالعربية |
| nameEn | string | ❌ | الاسم بالإنجليزية |
| description | string | ❌ | الوصف |
| color | string | ❌ | اللون |
| icon | string | ❌ | الأيقونة |

### 3. تحديث نظام فرعي

```
POST /api/trpc/customSystem.subSystems.update
```

**المعاملات:**
نفس معاملات الإنشاء + `id` (معرف النظام)

### 4. حذف نظام فرعي

```
POST /api/trpc/customSystem.subSystems.delete
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| id | number | ✅ | معرف النظام |

### 5. إحصائيات الأنظمة الفرعية

```
GET /api/trpc/customSystem.subSystems.stats
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| businessId | number | ✅ | معرف الشركة |

**مثال الاستجابة:**
```json
{
  "result": {
    "data": [
      {
        "subSystemId": 1,
        "treasuries": 2,
        "receipts": 10,
        "payments": 5,
        "balance": 5000
      }
    ]
  }
}
```
