# 📚 توثيق API - النظام المخصص (Custom System)

## نظرة عامة

النظام المخصص يوفر مجموعة من APIs لإدارة:
- الأنظمة الفرعية (Sub Systems)
- الخزائن (Treasuries)
- الأطراف (Parties)
- التصنيفات (Categories)
- سندات القبض والصرف (Vouchers)
- التحويلات والتسويات

## Base URL

```
/api/trpc/customSystem
```

## الـ Routers المتاحة

| Router | الوصف | الرابط |
|:---|:---|:---|
| subSystems | إدارة الأنظمة الفرعية | [التفاصيل](./custom-subsystems.md) |
| treasuries | إدارة الخزائن | [التفاصيل](./custom-treasuries.md) |
| parties | إدارة الأطراف | [التفاصيل](./custom-parties.md) |
| expenseCategories | إدارة التصنيفات | [التفاصيل](./custom-categories.md) |
| receiptVouchers | سندات القبض | [التفاصيل](./custom-vouchers.md#سندات-القبض) |
| paymentVouchers | سندات الصرف | [التفاصيل](./custom-vouchers.md#سندات-الصرف) |

## المصادقة

جميع الـ APIs تتطلب مصادقة عبر الجلسة (Session-based authentication).

## صيغة الاستجابة

جميع الاستجابات بصيغة JSON.
