# 📚 API الخزائن (Custom Treasuries)

## نظرة عامة

إدارة الخزائن (نقد، بنوك، محافظ إلكترونية).

## Endpoints

### 1. قائمة الخزائن

```
GET /api/trpc/customSystem.treasuries.list
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| businessId | number | ✅ | معرف الشركة |
| subSystemId | number | ❌ | معرف النظام الفرعي |
| treasuryType | string | ❌ | نوع الخزينة (cash, bank, wallet, exchange) |

### 2. إنشاء خزينة جديدة

```
POST /api/trpc/customSystem.treasuries.create
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| businessId | number | ✅ | معرف الشركة |
| subSystemId | number | ❌ | معرف النظام الفرعي |
| code | string | ✅ | كود الخزينة |
| nameAr | string | ✅ | الاسم بالعربية |
| nameEn | string | ❌ | الاسم بالإنجليزية |
| treasuryType | string | ✅ | نوع الخزينة |
| bankName | string | ❌ | اسم البنك |
| accountNumber | string | ❌ | رقم الحساب |
| iban | string | ❌ | رقم الآيبان |
| swiftCode | string | ❌ | سويفت كود |
| walletProvider | string | ❌ | مزود المحفظة |
| walletNumber | string | ❌ | رقم المحفظة |
| currency | string | ❌ | العملة |
| openingBalance | string | ❌ | الرصيد الافتتاحي |

### 3. تحديث خزينة

```
POST /api/trpc/customSystem.treasuries.update
```

**المعاملات:**
نفس معاملات الإنشاء + `id` (معرف الخزينة)

### 4. حذف خزينة

```
POST /api/trpc/customSystem.treasuries.delete
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| id | number | ✅ | معرف الخزينة |

### 5. تحديث رصيد خزينة

```
POST /api/trpc/customSystem.treasuries.updateBalance
```

**المعاملات:**
| المعامل | النوع | مطلوب | الوصف |
|:---|:---|:---:|:---|
| id | number | ✅ | معرف الخزينة |
| amount | string | ✅ | المبلغ |
| operation | string | ✅ | العملية (add, subtract) |
